# sym -> comp (t -> m) -> [1] {seq -> gate -> updateSqGate -> BPMN}
# ctl -> bpmn2petri (sep pool pm4py -> join msg) -> ctl convert -> call verifier
# res -> call_response -> [1] {seq // }
